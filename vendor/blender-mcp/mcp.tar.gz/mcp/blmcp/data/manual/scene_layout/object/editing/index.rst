
###################
  Editing Objects
###################

.. toctree::
   :maxdepth: 2
   :titlesonly:

   transform/index.rst
   mirror.rst
   clear.rst
   apply.rst
   snap.rst
   duplicate.rst
   duplicate_linked.rst
   join.rst
   asset.rst
   parent.rst
   Modifiers <modifiers.rst>
   constraints.rst
   track.rst
   relations/index.rst
   link_transfer/index.rst
   shading.rst
   rigid_body.rst
   convert.rst
   show_hide.rst
   cleanup.rst
   delete.rst
