
************
Introduction
************

In addition to modeling and animation, Blender can be used to edit videos.
There are two possible methods for this, one being the :doc:`Compositor </compositing/introduction>`
and the other, described in this chapter, being the Video Sequencer.
The Video Sequencer within Blender is a complete video editing system that allows you to combine multiple
video channels and add effects to them. You can use these effects to create powerful video edits,
especially when you combine it with the animation power of Blender!

To use the Video Sequencer, you load multiple video clips and lay them end-to-end (or in some cases, overlay them),
inserting fades and transitions to link the end of one clip to the beginning of another.
Finally, you can add audio and synchronize the timing of the video sequence to match it.

.. figure:: /images/video-editing_introduction_screen-layout.png

   Default Video Editing screen layout.
