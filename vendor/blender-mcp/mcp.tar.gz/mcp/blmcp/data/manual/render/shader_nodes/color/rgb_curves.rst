.. _bpy.types.ShaderNodeRGBCurve:
.. DO NOT EDIT FILE. This is simply a stub which copies everything from the link below.
.. include:: /compositing/types/color/adjust/rgb_curves.rst
   :start-after: .. --- copy below this line ---
