.. _painting-index:
.. _bpy.ops.paint:
.. _bpy.types.Paint:

########################
  Sculpting & Painting
########################

.. toctree::
   :maxdepth: 2

   introduction.rst
   brush/index.rst
   selection_visibility.rst
   navigation.rst


Modes
=====

.. toctree::
   :maxdepth: 2

   sculpting/index.rst
   texture_paint/index.rst
   vertex_paint/index.rst
   weight_paint/index.rst
   curves_sculpting/index.rst
